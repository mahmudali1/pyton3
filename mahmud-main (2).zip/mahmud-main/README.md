# mahmud
it consist of most all commands of Numpy
